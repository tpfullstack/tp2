import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { EventListComponent } from './components/event-list/event-list.component'; // Vérifiez que le chemin est correct

@NgModule({
  declarations: [
    AppComponent,
    EventListComponent // Assurez-vous que EventListComponent est bien ajouté ici
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
