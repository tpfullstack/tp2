import { Component } from '@angular/core';

@Component({
  selector: 'app-event-list', // Assurez-vous que le sélecteur correspond bien à celui utilisé dans app.component.html
  templateUrl: './event-list.component.html',
  styleUrls: ['./event-list.component.css']
})
export class EventListComponent { }
